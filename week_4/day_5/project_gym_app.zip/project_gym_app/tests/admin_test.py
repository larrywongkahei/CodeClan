import unittest

class Test_admin(unittest.TestCase):
    def setUp(self) -> None:
        return super().setUp()
