import unittest

from tests.members_test import *
from tests.classes_test import *


if __name__ == "__main__":
    unittest.main()