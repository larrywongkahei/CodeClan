class Classes:
    def __init__(self, name, fee, tutor_gender, availability, duration, max_capacity, id=None):
        self.name = name
        self.fee = fee
        self. tutor_gender = tutor_gender
        self.availability = availability
        self.duration = duration
        self.max_capacity = max_capacity
        self.id = id