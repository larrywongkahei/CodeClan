import java.util.ArrayList;

public class Bedroom extends Room{

    private int roomNumber;

    private RoomType roomType

    public Bedroom(ArrayList guest, RoomType roomType, int roomNumber) {
        super(guest, roomType.getCapacity());
        this.roomNumber = roomNumber;

    }
}
