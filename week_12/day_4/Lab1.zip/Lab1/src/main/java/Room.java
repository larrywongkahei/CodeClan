import java.util.ArrayList;

public class Room {

    private ArrayList< String > guests;
    private int capacity;

    public Room (ArrayList<> guest, int capacity) {
        this.guests = guest;
        this.capacity = capacity;
    }


}
